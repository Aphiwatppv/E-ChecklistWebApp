DELIMITER //
CREATE PROCEDURE application.GetChecklistByProcessId (IN p_ProcessId INT)
BEGIN
    SELECT * FROM application.Echecklist_Checklist WHERE ProcessId = p_ProcessId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE application.EChecklist_GetEntireChecklist()
BEGIN
    SELECT * FROM application.Echecklist_Checklist ;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE application.EChecklist_CreateChecklist(
    IN p_ChecklistName VARCHAR(255),
    IN p_ProcessId INT,
    IN p_ActiveFlag VARCHAR(10),
    IN p_Period VARCHAR(20),
    IN p_Description VARCHAR(255),
    IN p_CreateBy INT
)
BEGIN
    -- Check for duplicates
    IF EXISTS (SELECT 1 FROM application.Echecklist_Checklist
               WHERE ProcessId = p_ProcessId AND ChecklistName = p_ChecklistName) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'A checklist with the same name already exists for the given process.';
    ELSE
        -- Insert new checklist
        INSERT INTO application.Echecklist_Checklist
        (ChecklistName, ProcessId, ActiveFlag, Period, Description, CreateDate, CreateBy)
        VALUES
        (p_ChecklistName, p_ProcessId, p_ActiveFlag, p_Period, p_Description, CURRENT_TIMESTAMP, p_CreateBy);
    END IF;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE  application.EChecklist_AddItemChecklist (
    IN p_IndexItem INT,
    IN p_IdChecklist INT,
    IN p_ItemName VARCHAR(255),
    IN p_Unit VARCHAR(20),
    IN p_Description VARCHAR(255),
    IN p_CreateBy INT
)
BEGIN
    -- Insert the new item into the Echecklist_ItemChecklist table
    INSERT INTO application.Echecklist_ItemChecklist (
        IndexItem, 
        IdChecklist, 
        ItemName, 
        Unit, 
        Description, 
        CreateBy
    ) VALUES (
        p_IndexItem, 
        p_IdChecklist, 
        p_ItemName, 
        p_Unit, 
        p_Description, 
        p_CreateBy
    );
END //
DELIMITER ;
DELIMITER //

CREATE PROCEDURE application.EChecklist_GetChecklistItemsByChecklistId (
    IN p_IdChecklist INT
)
BEGIN
    -- Select items from the Echecklist_ItemChecklist table based on the provided IdChecklist
    SELECT 
        ItemId,
        IndexItem,
        IdChecklist,
        ItemName,
        Unit,
        Description,
        ActiveFlag,
        CreateDate,
        CreateBy
    FROM 
        application.Echecklist_ItemChecklist
    WHERE 
        IdChecklist = p_IdChecklist;
END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.EChecklist_AddItemConstant (
    IN p_ItemId INT,
    IN p_ConstantValue VARCHAR(255),
    IN p_Description VARCHAR(255),
    IN p_CreateBy INT
)
BEGIN
    -- Insert the new constant into the Echecklist_ItemConstant table
    INSERT INTO application.Echecklist_ItemConstant (
        ItemId, 
        ConstantValue, 
        Description, 
        CreateBy
    ) VALUES (
        p_ItemId, 
        p_ConstantValue, 
        p_Description, 
        p_CreateBy
    );
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE  application.EChecklist_GetConstantsByItemId (
    IN p_ItemId INT
)
BEGIN
    -- Select the constants from the Echecklist_ItemConstant table based on the provided ItemId
    SELECT 
        ConstantId,
        ItemId,
        ConstantValue,
        Description,
        CreateDate,
        CreateBy
    FROM 
        application.Echecklist_ItemConstant
    WHERE 
        ItemId = p_ItemId;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE application.EChecklist_RecordChecklistValue(
    IN p_ChecklistId INT,
    IN p_HistoricalId INT,
    IN p_ItemId INT,
    IN p_Value VARCHAR(255),
    IN p_AddingBy INT
)
BEGIN
    -- Insert the record directly
    INSERT INTO application.Echecklist_Record (
        ChecklistId, 
        HistoricalId, 
        ItemId, 
        Value, 
        AddingDate, 
        AddingBy
    ) VALUES (
        p_ChecklistId, 
        p_HistoricalId, 
        p_ItemId, 
        p_Value, 
        CURRENT_TIMESTAMP, 
        p_AddingBy
    );
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_CreateHistoricalRecord(
    IN p_ProcessId INT,
    IN p_ChecklistId INT,
    IN p_CreateBy INT,
    IN p_MachineName VARCHAR(255),
    IN p_LotNumber VARCHAR(255)
    
)
BEGIN
    DECLARE v_HistoricalId INT;
    
    -- Insert a new historical record
    INSERT INTO application.Echecklist_Historical (
        ProcessId, 
        ChecklistId, 
        CreateBy, 
        CreateDate,
        MachineName,
		LotNumber
    ) VALUES (
        p_ProcessId, 
        p_ChecklistId, 
        p_CreateBy,
        CURRENT_TIMESTAMP,
        P_MachineName,
        p_LotNumber
    );
    
    -- Get the last inserted HistoricalId
    SET v_HistoricalId = LAST_INSERT_ID();
    
    -- Return the newly created HistoricalId
    SELECT v_HistoricalId AS HistoricalId;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetLatestEchecklistHistoricalRecords(IN p_checklistId INT)
BEGIN
    SELECT 
        eh.HistoricalId,
        ep.ProcessName,
        ec.ChecklistName,
        ea.EN,
        eh.CreateDate,
        eh.MachineName,
        eh.LotNumber
	
    FROM 
        application.Echecklist_Historical eh
    JOIN 
        application.Echecklist_Checklist ec ON eh.ChecklistId = ec.IdChecklist
    JOIN 
        application.Echecklist_Authentication ea ON eh.CreateBy = ea.IdAuthen
    JOIN 
        application.Echecklist_Process ep ON ec.ProcessId = ep.ProcessId
	where 
		ec.IdChecklist = p_checklistId 
    ORDER BY 
        eh.CreateDate DESC
    LIMIT 100;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetEchecklistRecordsByHistoricalId(IN p_HistoricalId INT)
BEGIN
    SELECT 
        er.RecordId,
        er.HistoricalId,
        ic.IndexItem,
        ec.ChecklistName,
        ic.ItemName,
        er.Value,
        ic.Unit,
        ea.EN,
        er.AddingDate,
        eh.MachineName,
        eh.LotNumber
    FROM 
        application.Echecklist_Record er
    JOIN 
        application.Echecklist_Checklist ec ON er.ChecklistId = ec.IdChecklist
    JOIN 
        application.Echecklist_ItemChecklist ic ON er.ItemId = ic.ItemId
    JOIN 
        application.Echecklist_Authentication ea ON er.AddingBy = ea.IdAuthen
	join 
		application.Echecklist_Historical eh on er.HistoricalId = eh.HistoricalId
    WHERE 
        er.HistoricalId = p_HistoricalId
    ORDER BY 
        ic.IndexItem;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetDetailsByMachineName(IN machineName VARCHAR(255) , IN p_IdChecklist INT)
BEGIN
    SELECT 
        eh.HistoricalId,
        ep.ProcessName,
        ec.ChecklistName,
        ea.EN,
        eh.CreateDate,
        eh.MachineName,
        eh.LotNumber
    FROM 
        application.Echecklist_Historical eh
    JOIN 
        application.Echecklist_Checklist ec ON eh.ChecklistId = ec.IdChecklist
    JOIN 
        application.Echecklist_Authentication ea ON eh.CreateBy = ea.IdAuthen
    JOIN 
        application.Echecklist_Process ep ON ec.ProcessId = ep.ProcessId
    WHERE 
        eh.MachineName = machineName AND eh.ChecklistId = p_IdChecklist;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetDetailsByLotNumber(IN lotNumber VARCHAR(100))
BEGIN
    SELECT 
        eh.HistoricalId,
        ep.ProcessName,
        ec.ChecklistName,
        ea.EN,
        eh.CreateDate,
        eh.MachineName,
        eh.LotNumber
    FROM 
        application.Echecklist_Historical eh
    JOIN 
        application.Echecklist_Checklist ec ON eh.ChecklistId = ec.IdChecklist
    JOIN 
        application.Echecklist_Authentication ea ON eh.CreateBy = ea.IdAuthen
    JOIN 
        application.Echecklist_Process ep ON ec.ProcessId = ep.ProcessId
    WHERE 
        eh.LotNumber = lotNumber;
END //

DELIMITER ;
DELIMITER //

CREATE PROCEDURE application.Echecklist_GetDetailsByCreateDateRange(IN startDate DATETIME, IN endDate DATETIME)
BEGIN
    SELECT 
        eh.HistoricalId,
        ep.ProcessName,
        ec.ChecklistName,
        ea.EN,
        eh.CreateDate,
        eh.MachineName,
        eh.LotNumber
    FROM 
        application.Echecklist_Historical eh
    JOIN 
        application.Echecklist_Checklist ec ON eh.ChecklistId = ec.IdChecklist
    JOIN 
        application.Echecklist_Authentication ea ON eh.CreateBy = ea.IdAuthen
    JOIN 
        application.Echecklist_Process ep ON ec.ProcessId = ep.ProcessId
    WHERE 
        eh.CreateDate BETWEEN startDate AND endDate;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetChecklistData()
BEGIN
    SELECT 
        IdChecklist,
        ChecklistName
    FROM 
        application.Echecklist_Checklist;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.EditEchecklistDetails(
    IN p_HistoricalId INT,
    IN p_RecordId INT,
    IN p_LotNumber VARCHAR(100),
    IN p_MachineName VARCHAR(50),
    IN p_Value VARCHAR(255),
    IN p_AddingDate DATETIME
)
BEGIN
    -- Update the Echecklist_Historical table
    UPDATE application.Echecklist_Historical
    SET 
        LotNumber = p_LotNumber,
        MachineName = p_MachineName
    WHERE HistoricalId = p_HistoricalId;

    -- Update the Echecklist_Record table
    UPDATE application.Echecklist_Record
    SET 
        Value = p_Value,
        AddingDate = p_AddingDate
    WHERE RecordId = p_RecordId AND HistoricalId = p_HistoricalId;
END //

DELIMITER ;



