CREATE TABLE application.Echecklist_Authentication (
    IdAuthen INT PRIMARY KEY AUTO_INCREMENT,
    EN VARCHAR(10) UNIQUE NOT NULL,
    Passhash VARCHAR(255) NOT NULL,
    Salt VARCHAR(255) NOT NULL,
    Plant VARCHAR(10) NOT NULL,
    Role VARCHAR(10) NOT NULL,
    ActiveFlag VARCHAR(10), -- Active or Inactive
    CreateDate DATETIME NOT NULL,
    CreateBy VARCHAR(10) NOT NULL
);

CREATE TABLE application.Echecklist_Process (
    ProcessId INT PRIMARY KEY AUTO_INCREMENT,
    ProcessName VARCHAR(50) NOT NULL,
    ActiveFlag VARCHAR(10), -- Active or Inactive
    IdAuthen INT NOT NULL,
    CreateDate DATETIME NOT NULL,
    ProcessDetail VARCHAR(255),
	FOREIGN KEY (IdAuthen) REFERENCES application.Echecklist_Authentication(IdAuthen)
);

CREATE TABLE application.Echecklist_AllowingProcess (
    AllowingId INT PRIMARY KEY AUTO_INCREMENT,
    IdAuthen INT NOT NULL,
    ProcessId INT NOT NULL,
    AllowingFlag VARCHAR(10), -- Allow or Not Allow 
    AllowingDate DATETIME NOT NULL,
    FOREIGN KEY (IdAuthen) REFERENCES application.Echecklist_Authentication(IdAuthen),
    FOREIGN KEY (ProcessId) REFERENCES application.Echecklist_Process(ProcessId),
    UNIQUE (IdAuthen, ProcessId) -- Adding the unique constraint here
);


CREATE TABLE application.Echecklist_SaveLogAuthen (
    LogId INT PRIMARY KEY AUTO_INCREMENT,
    ActionBy_IdAuthen INT NOT NULL,
    Action VARCHAR(50) NOT NULL,
    TimeStamp DATETIME NOT NULL,
    FOREIGN KEY (ActionBy_IdAuthen) REFERENCES application.Echecklist_Authentication(IdAuthen)
);
