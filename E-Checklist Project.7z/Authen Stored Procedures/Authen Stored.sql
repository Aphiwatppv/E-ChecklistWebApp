-- log procedure
DELIMITER //
CREATE PROCEDURE application.Echecklist_SaveLog(
	IN p_IdAuthen Int,
    In p_Action VARCHAR(50) -- Change
)
Begin
	INSERT INTO application.Echecklist_SaveLogAuthen(ActionBy_IdAuthen,Action,TimeStamp)
    VALUES (p_IdAuthen, p_Action, NOW());
END//
DELIMITER ;
DELIMITER //

CREATE PROCEDURE application.GetEchecklistAuthenticationById(
    IN p_IdAuthen INT
)
BEGIN
    SELECT 
        IdAuthen,
        EN,
        Plant,
        Role,
        ActiveFlag,
        CreateDate,
        CreateBy
    FROM 
        application.Echecklist_Authentication
    WHERE 
        IdAuthen = p_IdAuthen;
END //

DELIMITER ;

DELIMITER //



CREATE PROCEDURE application.EChecklistGetAuthDetailByEN (IN p_EN VARCHAR(10))
BEGIN
    SELECT * FROM application.Echecklist_Authentication WHERE EN = p_EN;

END //

DELIMITER ;



DELIMITER //

CREATE PROCEDURE application.EChecklistGetAllowingProcessDetailByIdAuthen (
    IN p_IdAuthen INT
)
BEGIN
    SELECT 
        ap.AllowingId,
        ap.IdAuthen,
        ap.ProcessId,
        p.ProcessName,
        p.ProcessDetail,
        ap.AllowingFlag,
        ap.AllowingDate
    FROM 
        application.Echecklist_AllowingProcess ap
    JOIN 
        application.Echecklist_Process p ON ap.ProcessId = p.ProcessId
    WHERE 
        ap.IdAuthen = p_IdAuthen;

    CALL application.Echecklist_SaveLog(p_IdAuthen, 'Get Allowing Process Detail by IdAuthen');
END //

DELIMITER ;

DELIMITER ;



DELIMITER //

CREATE PROCEDURE application.EChecklistUpdatePasshashAndSaltByEN (IN p_IdAuthen INT, IN p_EN VARCHAR(10), IN p_Passhash VARCHAR(255), IN p_Salt VARCHAR(255))
BEGIN
    UPDATE application.Echecklist_Authentication
    SET Passhash = p_Passhash, Salt = p_Salt
    WHERE EN = p_EN;
    CALL application.Echecklist_SaveLog(p_IdAuthen, 'Update Passhash and Salt by EN');
END //

DELIMITER ;



DELIMITER //

CREATE PROCEDURE application.EChecklistChangeActiveFlagByIdOrEN (IN p_IdAuthen INT, IN p_EN VARCHAR(10))
BEGIN
    DECLARE currentFlag VARCHAR(10);
    
    -- Retrieve current flag value
    SELECT ActiveFlag INTO currentFlag FROM application.Echecklist_Authentication
    WHERE IdAuthen = p_IdAuthen OR EN = p_EN;
    
    -- Toggle the flag
    IF currentFlag = 'Active' THEN
        SET currentFlag = 'Inactive';
    ELSE
        SET currentFlag = 'Active';
    END IF;
    
    -- Update the flag
    UPDATE application.Echecklist_Authentication
    SET ActiveFlag = currentFlag
    WHERE IdAuthen = p_IdAuthen OR EN = p_EN;
    
    -- Log the action
    CALL application.Echecklist_SaveLog(p_IdAuthen, 'Change Active Flag by Id or EN');
END //
Echecklist_Process
DELIMITER ;




DELIMITER //

CREATE PROCEDURE application.EChecklistAddNewProcess (IN p_ProcessName VARCHAR(50), IN p_IdAuthen INT, IN p_ProcessDetail VARCHAR(255))
BEGIN
    INSERT INTO application.Echecklist_Process (ProcessName, ActiveFlag,IdAuthen, CreateDate, ProcessDetail)
    VALUES (p_ProcessName, 'Active', p_IdAuthen, NOW(), p_ProcessDetail);
    CALL application.Echecklist_SaveLog(p_IdAuthen, 'Add New Process');
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE application.EChecklistAdjustProcessNameByProcessId (IN p_ProcessId INT, IN p_ProcessName VARCHAR(50))
BEGIN
    UPDATE application.Echecklist_Process
    SET ProcessName = p_ProcessName
    WHERE ProcessId = p_ProcessId;
    -- Assuming ProcessId is sufficient to log the action
    CALL application.Echecklist_SaveLog(p_ProcessId, 'Adjust Process Name by ProcessId');
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE application.EChecklistChangeActiveFlagOfProcessByProcessId (IN p_ProcessId INT)
BEGIN
    DECLARE currentFlag VARCHAR(10);
    
    -- Retrieve current flag value
    SELECT ActiveFlag INTO currentFlag FROM application.Echecklist_Process
    WHERE ProcessId = p_ProcessId;
    
    -- Toggle the flag
    IF currentFlag = 'Active' THEN
        SET currentFlag = 'Inactive';
    ELSE
        SET currentFlag = 'Active';
    END IF;
    
    -- Update the flag
    UPDATE application.Echecklist_Process
    SET ActiveFlag = currentFlag
    WHERE ProcessId = p_ProcessId;
    
    -- Log the action
    CALL application.Echecklist_SaveLog(p_ProcessId, 'Change Active Flag of Process by ProcessId');
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE application.EChecklistChangeAllowingFlagByAllowingId (IN p_AllowingId INT)
BEGIN
    DECLARE currentFlag VARCHAR(10);
    
    -- Retrieve current flag value
    SELECT AllowingFlag INTO currentFlag FROM application.Echecklist_AllowingProcess
    WHERE AllowingId = p_AllowingId;
    
    -- Toggle the flag
    IF currentFlag = 'Allow' THEN
        SET currentFlag = 'Not Allow';
    ELSE
        SET currentFlag = 'Allow';
    END IF;
    
    -- Update the flag
    UPDATE application.Echecklist_AllowingProcess
    SET AllowingFlag = currentFlag
    WHERE AllowingId = p_AllowingId;
    
    -- Log the action
    CALL application.Echecklist_SaveLog(p_AllowingId, 'Change Allowing Flag by AllowingId');
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.EChecklistAddENToAllowingProcessTable (IN p_IdAuthen INT, IN p_ProcessId INT , IN p_IdAllowing INT)
BEGIN
    INSERT INTO application.Echecklist_AllowingProcess (IdAuthen, ProcessId, AllowingFlag, AllowingDate)
    VALUES (p_IdAuthen, p_ProcessId, 'Allow', NOW());
    CALL application.Echecklist_SaveLog(p_IdAllowing, 'Add EN to Allowing Process Table');
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.EChecklistGetAllProcesses()
BEGIN
    SELECT * FROM application.Echecklist_Process;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.EChecklistAddEchecklistAuthentication(
    IN p_EN VARCHAR(10),
    IN p_Passhash VARCHAR(255),
    IN p_Salt VARCHAR(255),
    IN p_Plant VARCHAR(10),
    IN p_Role VARCHAR(10),
    IN p_ActiveFlag VARCHAR(10),
    IN p_CreateBy VARCHAR(10)
)
BEGIN
    INSERT INTO application.Echecklist_Authentication (
        EN,
        Passhash,
        Salt,
        Plant,
        Role,
        ActiveFlag,
        CreateDate,
        CreateBy
    ) VALUES (
        p_EN,
        p_Passhash,
        p_Salt,
        p_Plant,
        p_Role,
        p_ActiveFlag,
        NOW(),
        p_CreateBy
    );
    
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.EchecklisCheckENExists(IN p_EN VARCHAR(10))
BEGIN
    DECLARE ENExists INT;
    
    -- Check if EN exists
    SELECT COUNT(*) INTO ENExists
    FROM application.Echecklist_Authentication
    WHERE EN = p_EN;
    
    -- Show message if EN exists
    IF ENExists > 0 THEN
        SELECT 'EN already Registered' AS Message;
    ELSE
        SELECT 'Fail to register' AS Message;
    END IF;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.GetEchecklistAuthenticationById(
    IN p_IdAuthen INT
)
BEGIN
    SELECT 
        IdAuthen,
        EN,
        Plant,
        Role,
        ActiveFlag,
        CreateDate,
        CreateBy
    FROM 
        application.Echecklist_Authentication
    WHERE 
        IdAuthen = p_IdAuthen;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetAuthenEN()
BEGIN

        SELECT EN, IdAuthen
        FROM application.Echecklist_Authentication
        WHERE Role != 'Engineer';

END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetProcess()
BEGIN

        SELECT EN, IdAuthen
        FROM application.Echecklist_Authentication
        WHERE Role != 'Engineer';

END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetActiveProcesses()
BEGIN
    SELECT ProcessId, ProcessName, ActiveFlag, IdAuthen, CreateDate, ProcessDetail
    FROM application.Echecklist_Process
    WHERE ActiveFlag = 'Active';
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetDetailsByIdAuthen(IN p_IdAuthen INT)
BEGIN
    SELECT AllowingId, IdAuthen, ProcessId, AllowingFlag, AllowingDate
    FROM application.Echecklist_AllowingProcess
    WHERE IdAuthen = p_IdAuthen;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetProcessNameByEN(IN p_EN VARCHAR(10))
BEGIN
    SELECT p.ProcessName, p.ActiveFlag
    FROM application.Echecklist_Process p
    JOIN application.Echecklist_AllowingProcess ap ON p.ProcessId = ap.ProcessId
    JOIN application.Echecklist_Authentication a ON a.IdAuthen = ap.IdAuthen
    WHERE a.EN = p_EN
      AND ap.AllowingFlag = 'Allow'
      AND p.ActiveFlag = 'Active';
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE application.Echecklist_GetDetailsByMachineLotDateRange(
    IN machineName VARCHAR(255), 
    IN lotNumber VARCHAR(255), 
    IN startDate DATETIME, 
    IN endDate DATETIME,
    In p_IdChecklist INT
)
BEGIN
    SELECT 
        eh.HistoricalId,
        ep.ProcessName,
        ec.ChecklistName,
        ea.EN,
        eh.CreateDate,
        eh.MachineName,
        eh.LotNumber
    FROM 
        application.Echecklist_Historical eh
    JOIN 
        application.Echecklist_Checklist ec ON eh.ChecklistId = ec.IdChecklist
    JOIN 
        application.Echecklist_Authentication ea ON eh.CreateBy = ea.IdAuthen
    JOIN 
        application.Echecklist_Process ep ON ec.ProcessId = ep.ProcessId
    WHERE 
        (eh.ChecklistId =  p_IdChecklist) AND ((machineName IS NULL OR machineName = '' OR eh.MachineName = machineName)
        AND (lotNumber IS NULL OR lotNumber = '' OR eh.LotNumber = lotNumber)
        AND (startDate IS NULL OR endDate IS NULL OR eh.CreateDate BETWEEN startDate AND endDate));
END //

DELIMITER ;





