CREATE TABLE application.Echecklist_Checklist (
    IdChecklist INT PRIMARY KEY AUTO_INCREMENT,
    ChecklistName VARCHAR(50) NOT NULL, -- maximum 255
    ProcessId INT,
    ActiveFlag VARCHAR(10) DEFAULT 'Active', -- Assuming default is 'Active'
    Period VARCHAR(20),
    Description VARCHAR(255),
    CreateDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    CreateBy INT,
    CONSTRAINT FK_Process FOREIGN KEY (ProcessId) REFERENCES application.Echecklist_Process(ProcessId),
    CONSTRAINT FK_CreateBy FOREIGN KEY (CreateBy) REFERENCES application.Echecklist_Authentication(IdAuthen),
    UNIQUE (ProcessId, ChecklistName)
);


CREATE TABLE application.Echecklist_ItemChecklist (
    ItemId INT PRIMARY KEY AUTO_INCREMENT,
    IndexItem INT,
    IdChecklist INT,
    ItemName VARCHAR(20) NOT NULL, -- maximum 100
    Unit VARCHAR(20),
    Description VARCHAR(255),
    ActiveFlag VARCHAR(10) DEFAULT 'Active', -- Set default to 'Active'
    CreateDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    CreateBy INT,
    FOREIGN KEY (IdChecklist) REFERENCES application.Echecklist_Checklist(IdChecklist),
    FOREIGN KEY (CreateBy) REFERENCES application.Echecklist_Authentication(IdAuthen),
    UNIQUE(IdChecklist, IndexItem)
);

CREATE TABLE application.Echecklist_ItemConstant (
    ConstantId INT PRIMARY KEY AUTO_INCREMENT,
    ItemId INT,
    ConstantValue VARCHAR(255),
    Description VARCHAR(255),
    CreateDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    CreateBy INT,
    FOREIGN KEY (ItemId) REFERENCES application.Echecklist_ItemChecklist(ItemId),
    FOREIGN KEY (CreateBy) REFERENCES application.Echecklist_Authentication(IdAuthen)
);

CREATE TABLE application.Echecklist_Historical (
    HistoricalId INT PRIMARY KEY AUTO_INCREMENT,
    ProcessId INT,
    ChecklistId INT,
    MachineName VARCHAR(50), -- maximum 100
    LotNumber VARCHAR(100), -- maximum 50 
    CreateBy INT,
    CreateDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (ProcessId, ChecklistId, CreateBy, CreateDate),
    FOREIGN KEY (CreateBy) REFERENCES application.Echecklist_Authentication(IdAuthen),
    FOREIGN KEY (ChecklistId) REFERENCES application.Echecklist_Checklist(IdChecklist)
);

CREATE TABLE application.Echecklist_Record (
    RecordId INT PRIMARY KEY AUTO_INCREMENT,
    ChecklistId INT,
    HistoricalId INT,
    ItemId INT,
    Value VARCHAR(255),
    AddingDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    AddingBy INT,
    FOREIGN KEY (ChecklistId) REFERENCES application.Echecklist_Checklist(IdChecklist),
    FOREIGN KEY (HistoricalId) REFERENCES application.Echecklist_Historical(HistoricalId),
    FOREIGN KEY (ItemId) REFERENCES application.Echecklist_ItemChecklist(ItemId),
    FOREIGN KEY (AddingBy) REFERENCES application.Echecklist_Authentication(IdAuthen)
);






