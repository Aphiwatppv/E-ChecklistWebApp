-- SELECT*FROM application.Echecklist_Authentication;


DELETE from application.Echecklist_Process
WHERE IdAuthen = 1;
CAlL application.EChecklistAddNewProcess('Test Process',1,'The test process in industrial electronics involves several stages to ensure that electronic devices and systems meet required standards and specifications.');
CAlL application.EChecklistAddNewProcess('Test Development Process',1,'The test development process is a systematic approach to creating, validating, and implementing tests to ensure that products meet specified requirements and standards.');
CAlL application.EChecklistAddNewProcess('Assembly Process',1,'The assembly process in industrial electronics involves the systematic integration of electronic components and subsystems to create a complete and functional electronic device or system.');
CAlL application.EChecklistAddNewProcess('Chemical Process',1,'The chemical process refers to the series of steps and reactions used to transform raw materials into desired chemical products.');
CALL application.EChecklistGetAllProcesses;
SELECT*FROM application.Echecklist_SaveLogAuthen;
CALL application.EChecklistGetAllProcesses();

CALL application.EChecklistAddENToAllowingProcessTable(1,4,1);

select * from application.Echecklist_AllowingProcess;
select * from application.Echecklist_Process;

CALL application.Echecklist_CreateChecklist('Assembly process checklist', 3, 'Active', 'Monthly', 'Description of the checklist', 1);
CALL application.EChecklist_GetChecklistsByProcessId(1);

CALL application.EChecklist_AddItemChecklist(1, 4, 'Motor Voltage', 'V', 'This is the voltage of joint 1', 1);
CALL application.EChecklist_AddItemChecklist(2, 4, 'Motor Voltage', 'V', 'This is the voltage of joint 2', 1);
CALL application.EChecklist_AddItemChecklist(3, 4, 'Type Motor', '', 'This is a type of Motors', 1);

select*from application.Echecklist_Checklist;
select*from application.Echecklist_ItemChecklist ;

CALL application.Echecklist_AddItemConstant(7, 'A', 'Type A', 1);
CALL application.Echecklist_AddItemConstant(7, 'B', 'Type B', 1);

CALL  application.Echecklist_GetConstantsByItemId(3);

select * from application.Echecklist_Historical;
select * from application.Echecklist_ItemChecklist;
select * from application.Echecklist_Record;
select* from application.Echecklist_Authentication;

CALL application.Echecklist_GetAuthenByENKeyword('1');
CALL application.Echecklist_GetEchecklistRecordsByHistoricalId(1);

CALL application.Echecklist_GetDetailsByCreateDateRange('2024-01-01 00:00:00', '2024-12-31 23:59:59');

ALTER TABLE application.Echecklist_Checklist
MODIFY COLUMN ChecklistName VARCHAR(255) NOT NULL;


ALTER TABLE application.Echecklist_ItemChecklist 
MODIFY COLUMN ItemName  VARCHAR(255) NOT NULL;

ALTER TABLE application.Echecklist_Historical 
MODIFY COLUMN MachineName VARCHAR(255) NOT NULL;

ALTER TABLE application.Echecklist_Historical 
MODIFY COLUMN LotNumber  VARCHAR(255) NOT NULL;
